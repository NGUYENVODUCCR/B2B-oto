﻿param(
  [string]$BaseUrl = 'http://localhost/B2B-oto-Dev/web/wp-json/b2b/v1',
  [string]$BuyerPhone = '',
  [string]$BuyerPassword = '',
  [string]$SellerPhone = '',
  [string]$SellerPassword = '',
  [string]$SupportPhone = '',
  [string]$SupportPassword = '',
  [string]$AdminPhone = '',
  [string]$AdminPassword = '',
  [string]$FlowVus = '30',
  [string]$FlowDuration = '10m',
  [string]$Stage100 = '3m',
  [string]$Stage300 = '3m',
  [string]$Stage500 = '3m',
  [string]$Stage700 = '3m',
  [string]$Stage1000 = '3m',
  [string]$SummaryJson = 'tests/k6/results-summary.json',
  [switch]$Quick,
  [switch]$RawOut
)

$ErrorActionPreference = 'Stop'

$k6 = Get-Command k6 -ErrorAction SilentlyContinue
if (-not $k6) {
  $k6Exe = 'C:\Program Files\k6\k6.exe'
  if (Test-Path $k6Exe) {
    $k6 = @{ Source = $k6Exe }
  } else {
    Write-Error "k6 is not installed. Install with: winget install k6.k6"
  }
}

if ($Quick) {
  $FlowVus = '10'
  $FlowDuration = '2m'
  $Stage100 = '1m'
  $Stage300 = '1m'
  $Stage500 = '1m'
  $Stage700 = '1m'
  $Stage1000 = '1m'
}

$env:BASE_URL = $BaseUrl
$env:BUYER_PHONE = $BuyerPhone
$env:BUYER_PASSWORD = $BuyerPassword
$env:SELLER_PHONE = $SellerPhone
$env:SELLER_PASSWORD = $SellerPassword
$env:SUPPORT_PHONE = $SupportPhone
$env:SUPPORT_PASSWORD = $SupportPassword
$env:ADMIN_PHONE = $AdminPhone
$env:ADMIN_PASSWORD = $AdminPassword
$env:FLOW_VUS = $FlowVus
$env:FLOW_DURATION = $FlowDuration
$env:STAGE_100 = $Stage100
$env:STAGE_300 = $Stage300
$env:STAGE_500 = $Stage500
$env:STAGE_700 = $Stage700
$env:STAGE_1000 = $Stage1000
$env:SUMMARY_JSON = $SummaryJson

$scriptPath = Join-Path $PSScriptRoot 'b2b-performance-load.js'

Write-Host "Using k6: $($k6.Source)"
Write-Host "BASE_URL: $BaseUrl"
Write-Host "FLOW_VUS: $FlowVus | FLOW_DURATION: $FlowDuration"
Write-Host "STAGES: 100=$Stage100, 300=$Stage300, 500=$Stage500, 700=$Stage700, 1000=$Stage1000"
Write-Host "SUMMARY_JSON: $SummaryJson"

if ($RawOut) {
  $rawPath = 'tests/k6/results-raw.json'
  & $k6.Source run --out "json=$rawPath" $scriptPath
} else {
  & $k6.Source run $scriptPath
}
