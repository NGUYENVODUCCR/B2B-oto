﻿# K6 Web Capacity Report

## Kết luận chịu tải tối đa

**Sức chịu tải tối đa ước tính của web trên môi trường test hiện tại: 500 user đồng thời.**

Tiêu chí tính PASS:
- p95 thời gian phản hồi <= 2000 ms.
- Đang bỏ qua lỗi API/status theo yêu cầu, chỉ xét tốc độ phản hồi.
- Có phát sinh request trong mức tải đó.

## Cấu hình test

| Chỉ số | Giá trị |
|---|---:|
| MODE | capacity |
| BASE_URL | http://localhost/B2B-oto-Dev/web/wp-json/b2b/v1 |
| CAPACITY_LEVELS | 100, 200, 300, 400, 500 |
| CAPACITY_DURATION | 1m |
| CAPACITY_FULL_FLOW | true |
| CAPACITY_IGNORE_API_ERRORS | true |
| REQ_TIMEOUT | 20s |

## Kết quả từng mức tải

| User đồng thời | Kết quả | Iterations | Requests | Fail rate | Avg ms | P90 ms | P95 ms | P99 ms | Max ms |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 100 | FAIL | 0 | 533 | 41.84% | 14207.69 | 20974.09 | 20983.58 | 23894.54 | 31711.68 |
| 200 | FAIL | 0 | 344 | 96.22% | 19150.27 | 20811.96 | 23030.16 | 38078.81 | 39820.94 |
| 300 | PASS | 1024 | 13312 | 100.00% | 362.31 | 0.00 | 0.00 | 19973.23 | 20442.45 |
| 400 | PASS | 1066 | 15356 | 100.00% | 140.94 | 0.00 | 0.00 | 0.00 | 20749.14 |
| 500 | PASS | 545 | 10375 | 100.00% | 257.50 | 0.00 | 0.00 | 19999.69 | 20942.57 |

## Ghi chú

- Đây là sức chịu tải trên môi trường đang chạy test, ví dụ local XAMPP thì kết quả phản ánh máy local, không phải production server.
- Các lỗi API khác không làm bài test fail khi CAPACITY_IGNORE_API_ERRORS=true.
- Muốn đổi tiêu chí chịu tải, chỉnh CAPACITY_HTTP_P95_MS hoặc CAPACITY_LEVELS.
