﻿# K6 B2B Marketplace Performance Report

## Thông tin bài test

| Chỉ số | Giá trị |
|---|---:|
| MODE | load_single |
| BASE_URL | http://localhost/B2B-oto-Dev/web/wp-json/b2b/v1 |
| Iterations | 120 |
| HTTP requests | 1562 |
| VUs max | 10 |
| HTTP p95 threshold | 2000 ms |
| HTTP p99 threshold | 4000 ms |
| Product p95 threshold | 2000 ms |

## Kết quả chính

| Metric | Giá trị |
|---|---:|
| http_req_failed | 0.00% |
| checks success rate | 100.00% |
| http_req_duration avg | 1145.98 ms |
| http_req_duration med | 1131.49 ms |
| http_req_duration p90 | 1468.09 ms |
| http_req_duration p95 | 1544.85 ms |
| http_req_duration p99 | 1772.78 ms |
| http_req_duration max | 2299.03 ms |

## Tốc độ riêng nhóm sản phẩm

| Metric | Giá trị |
|---|---:|
| product_list_duration_ms avg | 1134.86 ms |
| product_list_duration_ms med | 1067.71 ms |
| product_list_duration_ms p90 | 1431.47 ms |
| product_list_duration_ms p95 | 1611.64 ms |
| product_list_duration_ms p99 | 2016.90 ms |
| product_list_duration_ms max | 2062.84 ms |
| product_filter_duration_ms avg | 1192.32 ms |
| product_filter_duration_ms med | 1154.95 ms |
| product_filter_duration_ms p90 | 1529.91 ms |
| product_filter_duration_ms p95 | 1589.46 ms |
| product_filter_duration_ms p99 | 1867.70 ms |
| product_filter_duration_ms max | 1879.65 ms |
| product_detail_duration_ms avg | 0.00 ms |
| product_detail_duration_ms med | 0.00 ms |
| product_detail_duration_ms p90 | 0.00 ms |
| product_detail_duration_ms p95 | 0.00 ms |
| product_detail_duration_ms p99 | 0.00 ms |
| product_detail_duration_ms max | 0.00 ms |

## Tốc độ đăng nhập

| Metric | Giá trị |
|---|---:|
| auth_login_duration_ms avg | 828.71 ms |
| auth_login_duration_ms med | 828.71 ms |
| auth_login_duration_ms p90 | 1113.81 ms |
| auth_login_duration_ms p95 | 1149.44 ms |
| auth_login_duration_ms p99 | 1177.95 ms |
| auth_login_duration_ms max | 1185.08 ms |

## Threshold

| Metric | Trạng thái |
|---|---|
| http_req_failed | PASS |
| http_req_duration | PASS |
| api_fail_rate | PASS |
| flow_step_success_rate | PASS |
| flow_step_duration_ms | PASS |
| product_list_duration_ms | PASS |
| product_filter_duration_ms | PASS |

## Ghi chú

- File đã tối ưu để không login lại ở mỗi vòng lặp, trừ khi bật AUTH_EACH_ITER=true.
- Với MODE=load_single hoặc MODE=load, script chỉ login buyer và seller để giảm tải không cần thiết.
- WRITE_FLOW mặc định là false để tránh tạo nhiều dữ liệu trong DB khi load test.
- ENABLE_AI mặc định là false để tránh endpoint AI làm sai lệch kết quả hiệu năng API chính.
- Report Markdown có BOM UTF-8 để mở tiếng Việt tốt hơn trên Windows/PowerShell.
