﻿import http from 'k6/http';
import { check, group, sleep } from 'k6';
import { Counter, Trend, Rate } from 'k6/metrics';
import execution from 'k6/execution';

const BASE_URL = __ENV.BASE_URL || 'http://localhost/B2B-oto-Dev/web/wp-json/b2b/v1';
const MODE = __ENV.MODE || 'smoke';

const ENABLE_AI = (__ENV.ENABLE_AI || 'false') === 'true';
const WRITE_FLOW = (__ENV.WRITE_FLOW || 'false') === 'true';
const DEBUG_ERRORS = (__ENV.DEBUG_ERRORS || 'false') === 'true';
const DEBUG_SLOW = (__ENV.DEBUG_SLOW || 'false') === 'true';
const AUTH_EACH_ITER = (__ENV.AUTH_EACH_ITER || 'false') === 'true';
const DEBUG_AUTH = (__ENV.DEBUG_AUTH || 'false') === 'true';


const REQ_TIMEOUT = __ENV.REQ_TIMEOUT || '15s';
const SLOW_MS = Number(__ENV.SLOW_MS || 2000);

const HTTP_P95_MS = Number(__ENV.HTTP_P95_MS || 2000);
const HTTP_P99_MS = Number(__ENV.HTTP_P99_MS || 4000);
const STEP_P95_MS = Number(__ENV.STEP_P95_MS || 3000);
const PRODUCT_P95_MS = Number(__ENV.PRODUCT_P95_MS || 2000);

const CAPACITY_LEVELS = (__ENV.CAPACITY_LEVELS || '5,10,15,20,30,50')
  .split(',')
  .map((v) => Number(String(v).trim()))
  .filter((v) => Number.isFinite(v) && v > 0);

const CAPACITY_DURATION = __ENV.CAPACITY_DURATION || '2m';
const CAPACITY_GRACEFUL_STOP = __ENV.CAPACITY_GRACEFUL_STOP || '30s';
const CAPACITY_GAP_SECONDS = Number(__ENV.CAPACITY_GAP_SECONDS || 5);
const CAPACITY_HTTP_P95_MS = Number(__ENV.CAPACITY_HTTP_P95_MS || HTTP_P95_MS);
const CAPACITY_FAIL_RATE_MAX = Number(__ENV.CAPACITY_FAIL_RATE_MAX || 0.05);
const CAPACITY_IGNORE_API_ERRORS = (__ENV.CAPACITY_IGNORE_API_ERRORS || 'true') === 'true';
const CAPACITY_FULL_FLOW = (__ENV.CAPACITY_FULL_FLOW || 'true') === 'true';

const CREDENTIALS = {
  buyer: {
    phone: __ENV.BUYER_PHONE || '',
    password: __ENV.BUYER_PASSWORD || '',
  },
  seller: {
    phone: __ENV.SELLER_PHONE || '',
    password: __ENV.SELLER_PASSWORD || '',
  },
  support: {
    phone: __ENV.SUPPORT_PHONE || '',
    password: __ENV.SUPPORT_PASSWORD || '',
  },
  admin: {
    phone: __ENV.ADMIN_PHONE || '',
    password: __ENV.ADMIN_PASSWORD || '',
  },
};

const flowErrors = new Counter('flow_errors_total');
const stepDuration = new Trend('flow_step_duration_ms', true);
const stepSuccessRate = new Rate('flow_step_success_rate');

const httpReqDuration = new Trend('api_duration_ms', true);
const httpReqFailRate = new Rate('api_fail_rate');

const productListDuration = new Trend('product_list_duration_ms', true);
const productFilterDuration = new Trend('product_filter_duration_ms', true);
const productDetailDuration = new Trend('product_detail_duration_ms', true);
const authLoginDuration = new Trend('auth_login_duration_ms', true);

const capacityReqDuration = new Trend('capacity_req_duration_ms', true);
const capacityFailRate = new Rate('capacity_fail_rate');
const capacityRequests = new Counter('capacity_requests_total');
const capacityIterations = new Counter('capacity_iterations_total');

function endpoint(path) {
  return `${BASE_URL}${path}`;
}

function currentCapacityLevel() {
  if (MODE !== 'capacity') {
    return String(__ENV.LOAD_VUS || '');
  }

  try {
    const scenarioName = execution.scenario.name || '';
    const match = scenarioName.match(/^capacity_(\d+)$/);

    return match ? match[1] : scenarioName;
  } catch (_e) {
    
    return '';
  }
}

function addCapacityMetrics(duration, ok, sourceTags = {}) {
  if (MODE !== 'capacity') {
    return;
  }


  if (sourceTags.setup_role || String(sourceTags.step || '').startsWith('login_')) {
    return;
  }

  const level = sourceTags.level || currentCapacityLevel();

  if (!level) {
    return;
  }

  const tags = { level: String(level) };

  capacityReqDuration.add(duration, tags);
  capacityFailRate.add(!ok, tags);
  capacityRequests.add(1, tags);
}

function headers(token = '') {
  const h = {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  };

  if (token) {
    h.Authorization = `Bearer ${token}`;
  }

  return h;
}

function addStepSpecificDuration(duration, tags = {}) {
  if (tags.step === 'product_list') {
    productListDuration.add(duration, tags);
  }

  if (tags.step === 'product_filter') {
    productFilterDuration.add(duration, tags);
  }

  if (tags.step === 'product_detail') {
    productDetailDuration.add(duration, tags);
  }

  if (typeof tags.step === 'string' && tags.step.startsWith('login_')) {
    authLoginDuration.add(duration, tags);
  }
}

function request(method, path, body = null, token = '', tags = {}) {
  const payload = body === null ? null : JSON.stringify(body);

  const params = {
    headers: headers(token),
    tags: {
      path,
      method,
      ...tags,
    },
    timeout: REQ_TIMEOUT,
  };

  const res = http.request(method, endpoint(path), payload, params);
  const duration = res.timings.duration;

  httpReqDuration.add(duration, tags);
  stepDuration.add(duration, tags);
  addStepSpecificDuration(duration, tags);

  if (DEBUG_SLOW && duration > SLOW_MS) {
    console.warn(
      `[K6_SLOW] ${method} ${path} duration=${Math.round(duration)}ms status=${res.status} step=${tags.step || ''}`
    );
  }

  const ok = check(res, {
    [`${method} ${path} status 2xx`]: (r) => r.status >= 200 && r.status < 300,
  });

  addCapacityMetrics(duration, ok, tags);

  httpReqFailRate.add(!ok, tags);
  stepSuccessRate.add(ok, tags);

  if (!ok) {
    flowErrors.add(1, tags);

    if (DEBUG_ERRORS) {
      console.error(
        `[K6_ERROR] ${method} ${path} => status=${res.status} body=${String(res.body || '').slice(0, 500)}`
      );
    }
  }

  return res;
}

function parseJson(res) {
  try {
    return res.json();
  } catch (_e) {
    return null;
  }
}

function parseData(res) {
  const json = parseJson(res);
  return json?.data ?? null;
}

function debugTokenState(label, tokens = {}) {
  if ((__ENV.DEBUG_AUTH || 'false') !== 'true') {
    return;
  }

  console.log(
    `[K6_AUTH_STATE] ${label} buyer=${tokens?.buyer ? tokens.buyer.length : 0} seller=${tokens?.seller ? tokens.seller.length : 0} support=${tokens?.support ? tokens.support.length : 0} admin=${tokens?.admin ? tokens.admin.length : 0}`
  );
}

function parseListData(res) {
  const data = parseData(res);

  if (Array.isArray(data)) {
    return data;
  }

  if (Array.isArray(data?.items)) {
    return data.items;
  }

  if (Array.isArray(data?.products)) {
    return data.products;
  }

  if (Array.isArray(data?.data)) {
    return data.data;
  }

  return [];
}



function loginAs(role, tags = {}) {
  const creds = CREDENTIALS[role];

  if (!creds?.phone || !creds?.password) {
    if (DEBUG_AUTH || DEBUG_ERRORS) {
      console.warn(`[K6_AUTH] Missing credentials for role=${role}`);
    }

    return '';
  }

  const res = request('POST', '/auth/login', creds, '', {
    step: `login_${role}`,
    actor: role,
    ...tags,
  });

  const body = String(res.body || '');

  let token = '';

  const match = body.match(/"access_token"\s*:\s*"([^"]+)"/);

  if (match && match[1]) {
    token = match[1];
  }

  if (!token) {
    try {
      const json = JSON.parse(body);
      token =
        json?.data?.access_token ||
        json?.data?.accessToken ||
        json?.data?.token ||
        json?.access_token ||
        json?.accessToken ||
        json?.token ||
        '';
    } catch (_e) {
      token = '';
    }
  }

  if (!token) {
    console.warn(
      `[K6_AUTH] Token empty for role=${role}. status=${res.status} body=${body.slice(0, 1200)}`
    );
  } else if (DEBUG_AUTH) {
    console.log(`[K6_AUTH] Login OK role=${role}, token_length=${token.length}`);
  }

  return token;
}

function tokenBundle(roles = ['buyer', 'seller', 'support', 'admin']) {
  const tokens = {
    buyer: '',
    seller: '',
    support: '',
    admin: '',
  };

  for (const role of roles) {
    tokens[role] = loginAs(role, { setup_role: role });
  }

  return tokens;
}

function rolesForCurrentMode() {
  if (MODE === 'load' || MODE === 'load_single' || MODE === 'capacity') {
    return ['buyer', 'seller'];
  }

  return ['buyer', 'seller', 'support', 'admin'];
}

export function setup() {
  if (AUTH_EACH_ITER) {
    return {
      buyer: '',
      seller: '',
      support: '',
      admin: '',
    };
  }

  const tokens = tokenBundle(rolesForCurrentMode());

  debugTokenState('setup_return', tokens);

  return tokens;
}

function getTokens(setupTokens, roles = ['buyer', 'seller', 'support', 'admin']) {
  if (AUTH_EACH_ITER) {
    const tokens = tokenBundle(roles);
    debugTokenState('auth_each_iter_tokens', tokens);
    return tokens;
  }

  const tokens = setupTokens || {
    buyer: '',
    seller: '',
    support: '',
    admin: '',
  };

  if (__ITER === 0 && __VU <= 2) {
    debugTokenState(`scenario_received_vu_${__VU}`, tokens);
  }

  return tokens;
}

function runBuyerJourney(tokens) {
  group('flow1_buyer_seller', () => {
    const buyerToken = tokens?.buyer || '';
    const sellerToken = tokens?.seller || '';

 const productPage = Number(__ENV.PRODUCT_PAGE || 1);
const productPerPage = Number(__ENV.PRODUCT_PER_PAGE || 10);

const productListRes = request(
  'GET',
  `/product/list?page=${productPage}&per_page=${productPerPage}`,
  null,
  '',
  {
    flow: 'flow1',
    step: 'product_list',
    actor: 'public',
  }
);

    const productList = parseListData(productListRes);
    const firstProduct = productList[0] || {};
    const productId = firstProduct.id || firstProduct.product_id || Number(__ENV.TEST_PRODUCT_ID || 0);

    const productBrand = __ENV.PRODUCT_BRAND || 'toyota';

    request(
      'GET',
      `/products/filter?brand=${encodeURIComponent(productBrand)}&page=${productPage}&per_page=${productPerPage}`,
      null,
      '',
      {
        flow: 'flow1',
        step: 'product_filter',
        actor: 'public',
      }
    );

    if (productId) {
      request('GET', `/product/detail?id=${encodeURIComponent(productId)}`, null, '', {
        flow: 'flow1',
        step: 'product_detail',
        actor: 'public',
      });
    }

    if (ENABLE_AI) {
      request(
        'POST',
        '/ai/ask',
        { question: 'Tu van nhanh san pham phu hop cho xe sedan' },
        '',
        {
          flow: 'flow1',
          step: 'ai_chat',
          actor: 'public',
        }
      );
    }

    if (buyerToken) {
      request('GET', '/user/profile', null, buyerToken, {
        flow: 'flow1',
        step: 'profile_view',
        actor: 'buyer',
      });

      request('GET', '/chat/conversations', null, buyerToken, {
        flow: 'flow1',
        step: 'chat_conversations',
        actor: 'buyer',
      });

      request('GET', '/rfq/list', null, buyerToken, {
        flow: 'flow1',
        step: 'rfq_list',
        actor: 'buyer',
      });

      request('GET', '/quotation/by-rfq?rfq_id=1', null, buyerToken, {
        flow: 'flow1',
        step: 'quotation_by_rfq',
        actor: 'buyer',
      });

      request('GET', '/order/list?page=1&per_page=10', null, buyerToken, {
        flow: 'flow1',
        step: 'order_list_buyer',
        actor: 'buyer',
      });

      request('GET', '/wallet/balance', null, buyerToken, {
        flow: 'flow1',
        step: 'wallet_balance',
        actor: 'buyer',
      });

      request('GET', '/support/list', null, buyerToken, {
        flow: 'flow1',
        step: 'support_list_buyer',
        actor: 'buyer',
      });
    }

    if (sellerToken) {
      request('GET', '/product/my-products', null, sellerToken, {
        flow: 'flow1',
        step: 'seller_products',
        actor: 'seller',
      });

      request('GET', '/order/seller-history?page=1&per_page=10', null, sellerToken, {
        flow: 'flow1',
        step: 'seller_order_history',
        actor: 'seller',
      });

      request('GET', '/statistics/revenue', null, sellerToken, {
        flow: 'flow1',
        step: 'seller_revenue',
        actor: 'seller',
      });

      request('GET', '/support/seller-channel', null, sellerToken, {
        flow: 'flow1',
        step: 'seller_channel',
        actor: 'seller',
      });
    }
  });
}

function runBulkFlow(tokens) {
  group('flow2_bulk_purchase', () => {
    const buyerToken = tokens?.buyer || '';
    const sellerToken = tokens?.seller || '';
    const supportToken = tokens?.support || '';

    if (buyerToken) {
      if (WRITE_FLOW) {
        request('POST', '/support/bulk/start', {}, buyerToken, {
          flow: 'flow2',
          step: 'bulk_start',
          actor: 'buyer',
          write: 'true',
        });
      }

      request('GET', '/support/bulk/list', null, buyerToken, {
        flow: 'flow2',
        step: 'bulk_list_buyer',
        actor: 'buyer',
      });
    }

    if (supportToken) {
      request('GET', '/support/list?all=1&include_messages=1', null, supportToken, {
        flow: 'flow2',
        step: 'support_ticket_list',
        actor: 'support',
      });

      request('GET', '/support/agents', null, supportToken, {
        flow: 'flow2',
        step: 'support_agents',
        actor: 'support',
      });

      request('GET', '/order/list?page=1&per_page=10', null, supportToken, {
        flow: 'flow2',
        step: 'support_order_tracking',
        actor: 'support',
      });

      request('GET', '/payment/pending-releases?limit=20', null, supportToken, {
        flow: 'flow2',
        step: 'support_pending_releases',
        actor: 'support',
      });
    }

    if (sellerToken) {
      request('GET', '/support/seller-channel', null, sellerToken, {
        flow: 'flow2',
        step: 'bulk_seller_channel',
        actor: 'seller',
      });
    }
  });
}

function runAdminFlow(tokens) {
  group('admin_backoffice', () => {
    const adminToken = tokens?.admin || '';

    if (!adminToken) {
      return;
    }

    request('GET', '/seller-request/list', null, adminToken, {
      flow: 'admin',
      step: 'seller_requests',
      actor: 'admin',
    });

    request('GET', '/product/list?page=1&per_page=10', null, adminToken, {
      flow: 'admin',
      step: 'admin_products',
      actor: 'admin',
    });

    request('GET', '/admin/users?page=1&per_page=10', null, adminToken, {
      flow: 'admin',
      step: 'admin_users',
      actor: 'admin',
    });

    request('GET', '/admin/support/list', null, adminToken, {
      flow: 'admin',
      step: 'admin_support_list',
      actor: 'admin',
    });

    request('GET', '/payment/pending-releases?limit=20', null, adminToken, {
      flow: 'admin',
      step: 'admin_pending_releases',
      actor: 'admin',
    });

    request('GET', '/admin/chat/admin/messages', null, adminToken, {
      flow: 'admin',
      step: 'admin_internal_chat',
      actor: 'admin',
    });
  });
}


function durationToSeconds(duration) {
  const text = String(duration || '').trim();
  const match = text.match(/^(\d+(?:\.\d+)?)(ms|s|m|h)$/);

  if (!match) {
    return 60;
  }

  const value = Number(match[1]);
  const unit = match[2];

  if (unit === 'ms') return value / 1000;
  if (unit === 's') return value;
  if (unit === 'm') return value * 60;
  if (unit === 'h') return value * 3600;

  return 60;
}

function secondsToDuration(seconds) {
  return `${Math.max(0, Math.round(seconds))}s`;
}

function buildCapacityScenarios() {
  const scenarios = {};
  const durationSeconds = durationToSeconds(CAPACITY_DURATION);
  const gracefulSeconds = durationToSeconds(CAPACITY_GRACEFUL_STOP);

  CAPACITY_LEVELS.forEach((level, index) => {
    const startOffset = index * (durationSeconds + gracefulSeconds + CAPACITY_GAP_SECONDS);

    scenarios[`capacity_${level}`] = {
      executor: 'constant-vus',
      vus: level,
      duration: CAPACITY_DURATION,
      exec: 'capacityScenario',
      startTime: secondsToDuration(startOffset),
      gracefulStop: CAPACITY_GRACEFUL_STOP,
      tags: {
        level: String(level),
      },
    };
  });

  return scenarios;
}

function buildCapacityThresholds() {
  const thresholds = {};

  CAPACITY_LEVELS.forEach((level) => {
    thresholds[`capacity_req_duration_ms{level:${level}}`] = ['p(95)<100000000'];
    thresholds[`capacity_fail_rate{level:${level}}`] = ['rate<1.1'];
    thresholds[`capacity_requests_total{level:${level}}`] = ['count>=0'];
    thresholds[`capacity_iterations_total{level:${level}}`] = ['count>=0'];
  });

  return thresholds;
}

const SCENARIOS = {
  smoke: {
    flow_performance: {
      executor: 'constant-vus',
      vus: Number(__ENV.FLOW_VUS || 1),
      duration: __ENV.FLOW_DURATION || '10s',
      exec: 'flowPerformanceScenario',
      gracefulStop: '10s',
    },
  },

  flow: {
    flow_performance: {
      executor: 'constant-vus',
      vus: Number(__ENV.FLOW_VUS || 30),
      duration: __ENV.FLOW_DURATION || '10m',
      exec: 'flowPerformanceScenario',
      gracefulStop: '30s',
    },
  },

  load_single: {
    load_single_level: {
      executor: 'constant-vus',
      vus: Number(__ENV.LOAD_VUS || 50),
      duration: __ENV.LOAD_DURATION || '3m',
      exec: 'loadScenario',
      gracefulStop: '30s',
    },
  },

  capacity: buildCapacityScenarios(),

  load: {
    load_100_to_1000: {
      executor: 'ramping-vus',
      exec: 'loadScenario',
      startVUs: 0,
      stages: [
        { duration: __ENV.STAGE_100 || '3m', target: 100 },
        { duration: __ENV.STAGE_300 || '3m', target: 300 },
        { duration: __ENV.STAGE_500 || '3m', target: 500 },
        { duration: __ENV.STAGE_700 || '3m', target: 700 },
        { duration: __ENV.STAGE_1000 || '3m', target: 1000 },
        { duration: __ENV.STAGE_DOWN || '1m', target: 0 },
      ],
      gracefulRampDown: '30s',
      gracefulStop: '30s',
    },
  },
};

const DEFAULT_THRESHOLDS = {
  http_req_failed: ['rate<0.05'],
  http_req_duration: [`p(95)<${HTTP_P95_MS}`, `p(99)<${HTTP_P99_MS}`],
  api_fail_rate: ['rate<0.05'],
  flow_step_success_rate: ['rate>0.95'],
  flow_step_duration_ms: [`p(95)<${STEP_P95_MS}`],
  product_list_duration_ms: [`p(95)<${PRODUCT_P95_MS}`],
  product_filter_duration_ms: [`p(95)<${PRODUCT_P95_MS}`],
};

export const options = {
  scenarios: SCENARIOS[MODE] || SCENARIOS.smoke,


  thresholds: MODE === 'capacity' ? buildCapacityThresholds() : DEFAULT_THRESHOLDS,

  summaryTrendStats: ['avg', 'min', 'med', 'max', 'p(90)', 'p(95)', 'p(99)'],
};

export function flowPerformanceScenario(setupTokens) {
  const tokens = getTokens(setupTokens, ['buyer', 'seller', 'support', 'admin']);

  runBuyerJourney(tokens);
  runBulkFlow(tokens);
  runAdminFlow(tokens);

  sleep(Number(__ENV.SLEEP_BETWEEN_ITER || 1));
}

export function loadScenario(setupTokens) {
  const tokens = getTokens(setupTokens, ['buyer', 'seller']);

  runBuyerJourney({
    buyer: tokens.buyer,
    seller: tokens.seller,
    support: '',
    admin: '',
  });

  sleep(Number(__ENV.SLEEP_BETWEEN_ITER || 0.5));
}

export function capacityScenario(setupTokens) {
  const tokens = getTokens(setupTokens, ['buyer', 'seller', 'support', 'admin']);

  if (CAPACITY_FULL_FLOW) {
    runBuyerJourney({
      buyer: tokens.buyer,
      seller: tokens.seller,
      support: '',
      admin: '',
    });
  } else {
    runBuyerJourney({
      buyer: '',
      seller: '',
      support: '',
      admin: '',
    });
  }

  const level = currentCapacityLevel();

  if (level) {
    capacityIterations.add(1, { level });
  }

  sleep(Number(__ENV.SLEEP_BETWEEN_ITER || 0.5));
}


function findMetric(data, metricBaseName, level) {
  const exact = `${metricBaseName}{level:${level}}`;

  if (data.metrics?.[exact]) {
    return data.metrics[exact];
  }

  const suffix = `{level:${level}}`;
  const key = Object.keys(data.metrics || {}).find((metricName) => {
    return metricName.startsWith(metricBaseName) && metricName.includes(suffix);
  });

  return key ? data.metrics[key] : null;
}

function taggedMetricValue(data, metricBaseName, level, valueName, fallback = 0) {
  const metric = findMetric(data, metricBaseName, level);
  return metric?.values?.[valueName] ?? fallback;
}

function capacityLevelResult(data, level) {
  const requests = taggedMetricValue(data, 'capacity_requests_total', level, 'count');
  const iterations = taggedMetricValue(data, 'capacity_iterations_total', level, 'count');
  const failRate = taggedMetricValue(data, 'capacity_fail_rate', level, 'rate');
  const avg = taggedMetricValue(data, 'capacity_req_duration_ms', level, 'avg');
  const p90 = taggedMetricValue(data, 'capacity_req_duration_ms', level, 'p(90)');
  const p95 = taggedMetricValue(data, 'capacity_req_duration_ms', level, 'p(95)');
  const p99 = taggedMetricValue(data, 'capacity_req_duration_ms', level, 'p(99)');
  const max = taggedMetricValue(data, 'capacity_req_duration_ms', level, 'max');

  const hasData = requests > 0;
  const durationOk = hasData && p95 <= CAPACITY_HTTP_P95_MS;
  const failOk = CAPACITY_IGNORE_API_ERRORS || failRate <= CAPACITY_FAIL_RATE_MAX;

  return {
    level,
    requests,
    iterations,
    failRate,
    avg,
    p90,
    p95,
    p99,
    max,
    passed: hasData && durationOk && failOk,
  };
}

function buildCapacitySummary(data) {
  const results = CAPACITY_LEVELS.map((level) => capacityLevelResult(data, level));
  const passedLevels = results.filter((result) => result.passed).map((result) => result.level);
  const maxSupported = passedLevels.length ? Math.max(...passedLevels) : 0;

  const rows = results.map((result) => {
    return `| ${result.level} | ${result.passed ? 'PASS' : 'FAIL'} | ${result.iterations.toFixed(0)} | ${result.requests.toFixed(0)} | ${(result.failRate * 100).toFixed(2)}% | ${result.avg.toFixed(2)} | ${result.p90.toFixed(2)} | ${result.p95.toFixed(2)} | ${result.p99.toFixed(2)} | ${result.max.toFixed(2)} |`;
  }).join('\n');

  return `# K6 Web Capacity Report

## Kết luận chịu tải tối đa

**Sức chịu tải tối đa ước tính của web trên môi trường test hiện tại: ${maxSupported} user đồng thời.**

Tiêu chí tính PASS:
- p95 thời gian phản hồi <= ${CAPACITY_HTTP_P95_MS} ms.
- ${CAPACITY_IGNORE_API_ERRORS ? 'Đang bỏ qua lỗi API/status theo yêu cầu, chỉ xét tốc độ phản hồi.' : `Tỉ lệ lỗi <= ${(CAPACITY_FAIL_RATE_MAX * 100).toFixed(2)}%.`}
- Có phát sinh request trong mức tải đó.

## Cấu hình test

| Chỉ số | Giá trị |
|---|---:|
| MODE | ${MODE} |
| BASE_URL | ${BASE_URL} |
| CAPACITY_LEVELS | ${CAPACITY_LEVELS.join(', ')} |
| CAPACITY_DURATION | ${CAPACITY_DURATION} |
| CAPACITY_FULL_FLOW | ${CAPACITY_FULL_FLOW} |
| CAPACITY_IGNORE_API_ERRORS | ${CAPACITY_IGNORE_API_ERRORS} |
| REQ_TIMEOUT | ${REQ_TIMEOUT} |

## Kết quả từng mức tải

| User đồng thời | Kết quả | Iterations | Requests | Fail rate | Avg ms | P90 ms | P95 ms | P99 ms | Max ms |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|
${rows}

## Ghi chú

- Đây là sức chịu tải trên môi trường đang chạy test, ví dụ local XAMPP thì kết quả phản ánh máy local, không phải production server.
- Các lỗi API khác không làm bài test fail khi CAPACITY_IGNORE_API_ERRORS=true.
- Muốn đổi tiêu chí chịu tải, chỉnh CAPACITY_HTTP_P95_MS hoặc CAPACITY_LEVELS.
`;
}

function metricValue(data, metricName, valueName, fallback = 0) {
  return data.metrics?.[metricName]?.values?.[valueName] ?? fallback;
}

function thresholdStatus(data, metricName) {
  const thresholds = data.metrics?.[metricName]?.thresholds || {};
  const names = Object.keys(thresholds);

  if (!names.length) {
    return 'N/A';
  }

  return names.every((name) => thresholds[name]?.ok) ? 'PASS' : 'FAIL';
}

function durationRows(data, metricName, label) {
  const avg = metricValue(data, metricName, 'avg');
  const med = metricValue(data, metricName, 'med');
  const p90 = metricValue(data, metricName, 'p(90)');
  const p95 = metricValue(data, metricName, 'p(95)');
  const p99 = metricValue(data, metricName, 'p(99)');
  const max = metricValue(data, metricName, 'max');

  return `| ${label} avg | ${avg.toFixed(2)} ms |
| ${label} med | ${med.toFixed(2)} ms |
| ${label} p90 | ${p90.toFixed(2)} ms |
| ${label} p95 | ${p95.toFixed(2)} ms |
| ${label} p99 | ${p99.toFixed(2)} ms |
| ${label} max | ${max.toFixed(2)} ms |`;
}

function buildMarkdownSummary(data) {
  const iterations = metricValue(data, 'iterations', 'count');
  const httpReqs = metricValue(data, 'http_reqs', 'count');
  const httpFailedRate = metricValue(data, 'http_req_failed', 'rate');
  const checksRate = metricValue(data, 'checks', 'rate');
  const vusMax = metricValue(data, 'vus_max', 'max');

  return `# K6 B2B Marketplace Performance Report

## Thông tin bài test

| Chỉ số | Giá trị |
|---|---:|
| MODE | ${MODE} |
| BASE_URL | ${BASE_URL} |
| Iterations | ${iterations} |
| HTTP requests | ${httpReqs} |
| VUs max | ${vusMax} |
| HTTP p95 threshold | ${HTTP_P95_MS} ms |
| HTTP p99 threshold | ${HTTP_P99_MS} ms |
| Product p95 threshold | ${PRODUCT_P95_MS} ms |

## Kết quả chính

| Metric | Giá trị |
|---|---:|
| http_req_failed | ${(httpFailedRate * 100).toFixed(2)}% |
| checks success rate | ${(checksRate * 100).toFixed(2)}% |
${durationRows(data, 'http_req_duration', 'http_req_duration')}

## Tốc độ riêng nhóm sản phẩm

| Metric | Giá trị |
|---|---:|
${durationRows(data, 'product_list_duration_ms', 'product_list_duration_ms')}
${durationRows(data, 'product_filter_duration_ms', 'product_filter_duration_ms')}
${durationRows(data, 'product_detail_duration_ms', 'product_detail_duration_ms')}

## Tốc độ đăng nhập

| Metric | Giá trị |
|---|---:|
${durationRows(data, 'auth_login_duration_ms', 'auth_login_duration_ms')}

## Threshold

| Metric | Trạng thái |
|---|---|
| http_req_failed | ${thresholdStatus(data, 'http_req_failed')} |
| http_req_duration | ${thresholdStatus(data, 'http_req_duration')} |
| api_fail_rate | ${thresholdStatus(data, 'api_fail_rate')} |
| flow_step_success_rate | ${thresholdStatus(data, 'flow_step_success_rate')} |
| flow_step_duration_ms | ${thresholdStatus(data, 'flow_step_duration_ms')} |
| product_list_duration_ms | ${thresholdStatus(data, 'product_list_duration_ms')} |
| product_filter_duration_ms | ${thresholdStatus(data, 'product_filter_duration_ms')} |

## Ghi chú

- File đã tối ưu để không login lại ở mỗi vòng lặp, trừ khi bật AUTH_EACH_ITER=true.
- Với MODE=load_single hoặc MODE=load, script chỉ login buyer và seller để giảm tải không cần thiết.
- WRITE_FLOW mặc định là false để tránh tạo nhiều dữ liệu trong DB khi load test.
- ENABLE_AI mặc định là false để tránh endpoint AI làm sai lệch kết quả hiệu năng API chính.
- Report Markdown có BOM UTF-8 để mở tiếng Việt tốt hơn trên Windows/PowerShell.
`;
}

export function handleSummary(data) {
  const iterations = metricValue(data, 'iterations', 'count');

  const summaryJsonPath =
    __ENV.SUMMARY_JSON || 'web/app/themes/my-theme/tests/k6/results-summary.json';

  const summaryMdPath =
    __ENV.SUMMARY_MD || summaryJsonPath.replace(/\.json$/i, '.md');

  if (MODE === 'capacity') {
    const capacityMd = buildCapacitySummary(data);
    const summaryLine = capacityMd.match(/Sức chịu tải tối đa ước tính của web[^\n]+/)?.[0] || 'Capacity test complete.';

    return {
      stdout: `\n${summaryLine}\n`,
      [summaryJsonPath]: JSON.stringify(data, null, 2),
      [summaryMdPath]: `\ufeff${capacityMd}`,
    };
  }

  return {
    stdout: `\nK6 run complete. Iterations: ${iterations}\n`,
    [summaryJsonPath]: JSON.stringify(data, null, 2),
    [summaryMdPath]: `\ufeff${buildMarkdownSummary(data)}`,
  };
}

export default function (setupTokens) {
  flowPerformanceScenario(setupTokens);
}
