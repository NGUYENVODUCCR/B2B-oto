﻿# K6 B2B Marketplace Performance Report

## Thông tin bài test

| Chỉ số | Giá trị |
|---|---:|
| MODE | load_single |
| BASE_URL | http://localhost/B2B-oto-Dev/web/wp-json/b2b/v1 |
| Iterations | 4 |
| HTTP requests | 54 |
| VUs max | 1 |
| HTTP p95 threshold | 2000 ms |
| HTTP p99 threshold | 4000 ms |
| Product p95 threshold | 2000 ms |

## Kết quả chính

| Metric | Giá trị |
|---|---:|
| http_req_failed | 0.00% |
| checks success rate | 100.00% |
| http_req_duration avg | 449.28 ms |
| http_req_duration med | 405.82 ms |
| http_req_duration p90 | 510.93 ms |
| http_req_duration p95 | 733.68 ms |
| http_req_duration p99 | 998.62 ms |
| http_req_duration max | 1236.27 ms |

## Tốc độ riêng nhóm sản phẩm

| Metric | Giá trị |
|---|---:|
| product_list_duration_ms avg | 821.91 ms |
| product_list_duration_ms med | 774.85 ms |
| product_list_duration_ms p90 | 1101.75 ms |
| product_list_duration_ms p95 | 1169.01 ms |
| product_list_duration_ms p99 | 1222.82 ms |
| product_list_duration_ms max | 1236.27 ms |
| product_filter_duration_ms avg | 434.21 ms |
| product_filter_duration_ms med | 428.70 ms |
| product_filter_duration_ms p90 | 474.63 ms |
| product_filter_duration_ms p95 | 483.92 ms |
| product_filter_duration_ms p99 | 491.35 ms |
| product_filter_duration_ms max | 493.20 ms |
| product_detail_duration_ms avg | 0.00 ms |
| product_detail_duration_ms med | 0.00 ms |
| product_detail_duration_ms p90 | 0.00 ms |
| product_detail_duration_ms p95 | 0.00 ms |
| product_detail_duration_ms p99 | 0.00 ms |
| product_detail_duration_ms max | 0.00 ms |

## Tốc độ đăng nhập

| Metric | Giá trị |
|---|---:|
| auth_login_duration_ms avg | 549.76 ms |
| auth_login_duration_ms med | 549.76 ms |
| auth_login_duration_ms p90 | 577.64 ms |
| auth_login_duration_ms p95 | 581.13 ms |
| auth_login_duration_ms p99 | 583.91 ms |
| auth_login_duration_ms max | 584.61 ms |

## Threshold

| Metric | Trạng thái |
|---|---|
| http_req_failed | PASS |
| http_req_duration | PASS |
| api_fail_rate | PASS |
| flow_step_success_rate | PASS |
| flow_step_duration_ms | PASS |
| product_list_duration_ms | PASS |
| product_filter_duration_ms | PASS |

## Ghi chú

- File đã tối ưu để không login lại ở mỗi vòng lặp, trừ khi bật AUTH_EACH_ITER=true.
- Với MODE=load_single hoặc MODE=load, script chỉ login buyer và seller để giảm tải không cần thiết.
- WRITE_FLOW mặc định là false để tránh tạo nhiều dữ liệu trong DB khi load test.
- ENABLE_AI mặc định là false để tránh endpoint AI làm sai lệch kết quả hiệu năng API chính.
- Report Markdown có BOM UTF-8 để mở tiếng Việt tốt hơn trên Windows/PowerShell.
