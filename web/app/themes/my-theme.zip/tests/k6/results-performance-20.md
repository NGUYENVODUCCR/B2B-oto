﻿# K6 B2B Marketplace Performance Report

## Thông tin bài test

| Chỉ số | Giá trị |
|---|---:|
| MODE | load_single |
| BASE_URL | http://localhost/B2B-oto-Dev/web/wp-json/b2b/v1 |
| Iterations | 110 |
| HTTP requests | 1432 |
| VUs max | 20 |
| HTTP p95 threshold | 2000 ms |
| HTTP p99 threshold | 4000 ms |
| Product p95 threshold | 2000 ms |

## Kết quả chính

| Metric | Giá trị |
|---|---:|
| http_req_failed | 0.00% |
| checks success rate | 100.00% |
| http_req_duration avg | 2592.65 ms |
| http_req_duration med | 2386.45 ms |
| http_req_duration p90 | 3133.17 ms |
| http_req_duration p95 | 3815.11 ms |
| http_req_duration p99 | 6555.26 ms |
| http_req_duration max | 9867.53 ms |

## Tốc độ riêng nhóm sản phẩm

| Metric | Giá trị |
|---|---:|
| product_list_duration_ms avg | 2683.92 ms |
| product_list_duration_ms med | 2295.15 ms |
| product_list_duration_ms p90 | 3238.81 ms |
| product_list_duration_ms p95 | 6372.61 ms |
| product_list_duration_ms p99 | 6817.83 ms |
| product_list_duration_ms max | 6939.65 ms |
| product_filter_duration_ms avg | 3130.94 ms |
| product_filter_duration_ms med | 2629.41 ms |
| product_filter_duration_ms p90 | 3784.55 ms |
| product_filter_duration_ms p95 | 9015.74 ms |
| product_filter_duration_ms p99 | 9722.52 ms |
| product_filter_duration_ms max | 9867.53 ms |
| product_detail_duration_ms avg | 0.00 ms |
| product_detail_duration_ms med | 0.00 ms |
| product_detail_duration_ms p90 | 0.00 ms |
| product_detail_duration_ms p95 | 0.00 ms |
| product_detail_duration_ms p99 | 0.00 ms |
| product_detail_duration_ms max | 0.00 ms |

## Tốc độ đăng nhập

| Metric | Giá trị |
|---|---:|
| auth_login_duration_ms avg | 1196.07 ms |
| auth_login_duration_ms med | 1196.07 ms |
| auth_login_duration_ms p90 | 1701.85 ms |
| auth_login_duration_ms p95 | 1765.07 ms |
| auth_login_duration_ms p99 | 1815.65 ms |
| auth_login_duration_ms max | 1828.30 ms |

## Threshold

| Metric | Trạng thái |
|---|---|
| http_req_failed | PASS |
| http_req_duration | FAIL |
| api_fail_rate | PASS |
| flow_step_success_rate | PASS |
| flow_step_duration_ms | FAIL |
| product_list_duration_ms | FAIL |
| product_filter_duration_ms | FAIL |

## Ghi chú

- File đã tối ưu để không login lại ở mỗi vòng lặp, trừ khi bật AUTH_EACH_ITER=true.
- Với MODE=load_single hoặc MODE=load, script chỉ login buyer và seller để giảm tải không cần thiết.
- WRITE_FLOW mặc định là false để tránh tạo nhiều dữ liệu trong DB khi load test.
- ENABLE_AI mặc định là false để tránh endpoint AI làm sai lệch kết quả hiệu năng API chính.
- Report Markdown có BOM UTF-8 để mở tiếng Việt tốt hơn trên Windows/PowerShell.
