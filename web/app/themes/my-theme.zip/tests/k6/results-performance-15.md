﻿# K6 B2B Marketplace Performance Report

## Thông tin bài test

| Chỉ số | Giá trị |
|---|---:|
| MODE | load_single |
| BASE_URL | http://localhost/B2B-oto-Dev/web/wp-json/b2b/v1 |
| Iterations | 119 |
| HTTP requests | 1549 |
| VUs max | 15 |
| HTTP p95 threshold | 2000 ms |
| HTTP p99 threshold | 4000 ms |
| Product p95 threshold | 2000 ms |

## Kết quả chính

| Metric | Giá trị |
|---|---:|
| http_req_failed | 0.00% |
| checks success rate | 100.00% |
| http_req_duration avg | 1772.57 ms |
| http_req_duration med | 1661.12 ms |
| http_req_duration p90 | 2263.46 ms |
| http_req_duration p95 | 2317.05 ms |
| http_req_duration p99 | 2508.10 ms |
| http_req_duration max | 3315.92 ms |

## Tốc độ riêng nhóm sản phẩm

| Metric | Giá trị |
|---|---:|
| product_list_duration_ms avg | 1707.03 ms |
| product_list_duration_ms med | 1648.79 ms |
| product_list_duration_ms p90 | 2182.97 ms |
| product_list_duration_ms p95 | 2372.40 ms |
| product_list_duration_ms p99 | 3214.79 ms |
| product_list_duration_ms max | 3315.92 ms |
| product_filter_duration_ms avg | 1845.71 ms |
| product_filter_duration_ms med | 1789.44 ms |
| product_filter_duration_ms p90 | 2228.39 ms |
| product_filter_duration_ms p95 | 2306.42 ms |
| product_filter_duration_ms p99 | 2394.72 ms |
| product_filter_duration_ms max | 2427.88 ms |
| product_detail_duration_ms avg | 0.00 ms |
| product_detail_duration_ms med | 0.00 ms |
| product_detail_duration_ms p90 | 0.00 ms |
| product_detail_duration_ms p95 | 0.00 ms |
| product_detail_duration_ms p99 | 0.00 ms |
| product_detail_duration_ms max | 0.00 ms |

## Tốc độ đăng nhập

| Metric | Giá trị |
|---|---:|
| auth_login_duration_ms avg | 805.40 ms |
| auth_login_duration_ms med | 805.40 ms |
| auth_login_duration_ms p90 | 1061.24 ms |
| auth_login_duration_ms p95 | 1093.22 ms |
| auth_login_duration_ms p99 | 1118.81 ms |
| auth_login_duration_ms max | 1125.20 ms |

## Threshold

| Metric | Trạng thái |
|---|---|
| http_req_failed | PASS |
| http_req_duration | FAIL |
| api_fail_rate | PASS |
| flow_step_success_rate | PASS |
| flow_step_duration_ms | PASS |
| product_list_duration_ms | FAIL |
| product_filter_duration_ms | FAIL |

## Ghi chú

- File đã tối ưu để không login lại ở mỗi vòng lặp, trừ khi bật AUTH_EACH_ITER=true.
- Với MODE=load_single hoặc MODE=load, script chỉ login buyer và seller để giảm tải không cần thiết.
- WRITE_FLOW mặc định là false để tránh tạo nhiều dữ liệu trong DB khi load test.
- ENABLE_AI mặc định là false để tránh endpoint AI làm sai lệch kết quả hiệu năng API chính.
- Report Markdown có BOM UTF-8 để mở tiếng Việt tốt hơn trên Windows/PowerShell.
