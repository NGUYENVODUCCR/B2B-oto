﻿# K6 performance + load test for B2B Marketplace

## 1) Set environment variables

```powershell
$env:BASE_URL='http://localhost/B2B-oto-Dev/web/wp-json/b2b/v1'
$env:BUYER_PHONE='0388393181'
$env:BUYER_PASSWORD='123456'
$env:SELLER_PHONE='0875889620'
$env:SELLER_PASSWORD='123456'
$env:SUPPORT_PHONE='0389393990'
$env:SUPPORT_PASSWORD='123456'
$env:ADMIN_PHONE='0875889628'
$env:ADMIN_PASSWORD='123456'
```

## 2) Run flow + load test (100 -> 1000 users)

```powershell
k6 run .\tests\k6\b2b-performance-load.js
```

## 3) Collect results

- Summary JSON file: `tests/k6/results-summary.json` (or override with `SUMMARY_JSON`)
- Optional raw metrics output:

```powershell
k6 run --out json=tests\k6\results-raw.json .\tests\k6\b2b-performance-load.js
```

## 4) Quick tuning

- `FLOW_VUS` default: `30`
- `FLOW_DURATION` default: `10m`
- Load stages:
  - `STAGE_100` / `STAGE_300` / `STAGE_500` / `STAGE_700` / `STAGE_1000` (default each stage: `3m`)
- Main pass/fail thresholds:
  - `http_req_failed < 5%`
  - `http_req_duration p95 < 2000ms`
  - `flow_step_success_rate > 95%`
