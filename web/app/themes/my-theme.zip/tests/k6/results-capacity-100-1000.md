﻿# K6 Web Capacity Report

## Kết luận chịu tải tối đa

**Sức chịu tải tối đa ước tính của web trên môi trường test hiện tại: 1000 user đồng thời.**

Tiêu chí tính PASS:
- p95 thời gian phản hồi <= 2000 ms.
- Đang bỏ qua lỗi API/status theo yêu cầu, chỉ xét tốc độ phản hồi.
- Có phát sinh request trong mức tải đó.

## Cấu hình test

| Chỉ số | Giá trị |
|---|---:|
| MODE | capacity |
| BASE_URL | http://localhost/B2B-oto-Dev/web/wp-json/b2b/v1 |
| CAPACITY_LEVELS | 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000 |
| CAPACITY_DURATION | 1m |
| CAPACITY_FULL_FLOW | true |
| CAPACITY_IGNORE_API_ERRORS | true |
| REQ_TIMEOUT | 20s |

## Kết quả từng mức tải

| User đồng thời | Kết quả | Iterations | Requests | Fail rate | Avg ms | P90 ms | P95 ms | P99 ms | Max ms |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 100 | FAIL | 0 | 414 | 88.89% | 19328.37 | 20266.57 | 20268.87 | 20374.29 | 20409.99 |
| 200 | FAIL | 12 | 990 | 100.00% | 6472.77 | 20136.96 | 20616.88 | 21175.88 | 21605.21 |
| 300 | PASS | 64 | 3452 | 100.00% | 701.07 | 0.00 | 0.00 | 20015.87 | 20410.65 |
| 400 | FAIL | 2 | 3209 | 100.00% | 1227.90 | 0.00 | 18136.23 | 20176.04 | 20475.94 |
| 500 | PASS | 1 | 2102 | 100.00% | 95.31 | 0.00 | 0.00 | 0.00 | 20206.96 |
| 600 | PASS | 0 | 655 | 100.00% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 700 | PASS | 0 | 777 | 100.00% | 129.86 | 0.00 | 0.00 | 0.00 | 20320.81 |
| 800 | PASS | 0 | 578 | 100.00% | 68.34 | 0.00 | 0.00 | 0.00 | 19967.13 |
| 900 | PASS | 0 | 1594 | 100.00% | 12.56 | 0.00 | 0.00 | 0.00 | 20014.54 |
| 1000 | PASS | 0 | 376 | 100.00% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |

## Ghi chú

- Đây là sức chịu tải trên môi trường đang chạy test, ví dụ local XAMPP thì kết quả phản ánh máy local, không phải production server.
- Các lỗi API khác không làm bài test fail khi CAPACITY_IGNORE_API_ERRORS=true.
- Muốn đổi tiêu chí chịu tải, chỉnh CAPACITY_HTTP_P95_MS hoặc CAPACITY_LEVELS.
