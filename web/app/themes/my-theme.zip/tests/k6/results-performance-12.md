﻿# K6 B2B Marketplace Performance Report

## Thông tin bài test

| Chỉ số | Giá trị |
|---|---:|
| MODE | load_single |
| BASE_URL | http://localhost/B2B-oto-Dev/web/wp-json/b2b/v1 |
| Iterations | 125 |
| HTTP requests | 1627 |
| VUs max | 12 |
| HTTP p95 threshold | 2000 ms |
| HTTP p99 threshold | 4000 ms |
| Product p95 threshold | 2000 ms |

## Kết quả chính

| Metric | Giá trị |
|---|---:|
| http_req_failed | 0.00% |
| checks success rate | 100.00% |
| http_req_duration avg | 1363.42 ms |
| http_req_duration med | 1229.07 ms |
| http_req_duration p90 | 1743.85 ms |
| http_req_duration p95 | 1808.98 ms |
| http_req_duration p99 | 2518.80 ms |
| http_req_duration max | 3820.50 ms |

## Tốc độ riêng nhóm sản phẩm

| Metric | Giá trị |
|---|---:|
| product_list_duration_ms avg | 1346.83 ms |
| product_list_duration_ms med | 1217.60 ms |
| product_list_duration_ms p90 | 1668.54 ms |
| product_list_duration_ms p95 | 2249.81 ms |
| product_list_duration_ms p99 | 2670.99 ms |
| product_list_duration_ms max | 3820.50 ms |
| product_filter_duration_ms avg | 1358.78 ms |
| product_filter_duration_ms med | 1334.12 ms |
| product_filter_duration_ms p90 | 1695.50 ms |
| product_filter_duration_ms p95 | 1742.78 ms |
| product_filter_duration_ms p99 | 1888.93 ms |
| product_filter_duration_ms max | 2282.19 ms |
| product_detail_duration_ms avg | 0.00 ms |
| product_detail_duration_ms med | 0.00 ms |
| product_detail_duration_ms p90 | 0.00 ms |
| product_detail_duration_ms p95 | 0.00 ms |
| product_detail_duration_ms p99 | 0.00 ms |
| product_detail_duration_ms max | 0.00 ms |

## Tốc độ đăng nhập

| Metric | Giá trị |
|---|---:|
| auth_login_duration_ms avg | 929.13 ms |
| auth_login_duration_ms med | 929.13 ms |
| auth_login_duration_ms p90 | 1205.64 ms |
| auth_login_duration_ms p95 | 1240.20 ms |
| auth_login_duration_ms p99 | 1267.85 ms |
| auth_login_duration_ms max | 1274.76 ms |

## Threshold

| Metric | Trạng thái |
|---|---|
| http_req_failed | PASS |
| http_req_duration | PASS |
| api_fail_rate | PASS |
| flow_step_success_rate | PASS |
| flow_step_duration_ms | PASS |
| product_list_duration_ms | FAIL |
| product_filter_duration_ms | PASS |

## Ghi chú

- File đã tối ưu để không login lại ở mỗi vòng lặp, trừ khi bật AUTH_EACH_ITER=true.
- Với MODE=load_single hoặc MODE=load, script chỉ login buyer và seller để giảm tải không cần thiết.
- WRITE_FLOW mặc định là false để tránh tạo nhiều dữ liệu trong DB khi load test.
- ENABLE_AI mặc định là false để tránh endpoint AI làm sai lệch kết quả hiệu năng API chính.
- Report Markdown có BOM UTF-8 để mở tiếng Việt tốt hơn trên Windows/PowerShell.
